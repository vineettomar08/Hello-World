from django.contrib import admin
from college_form.models import Form

# Register your models here.

admin.site.register(Form)