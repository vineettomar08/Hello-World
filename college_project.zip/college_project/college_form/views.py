from django.shortcuts import render,HttpResponseRedirect
from .models import Form

# Create your views here.
def default(request):
    resp=render(request,'home.html')
    return resp

def newuser(request):
    resp=render(request,'register.html')
    return resp

def forgot(request):
    pass
    # if(request.method=='GET'):
    #     resp=render(request,'forgotpass.html')
    #     return resp
    # else:
    #     r = request.POST.get('roll_no')
    #     e = request.POST.get('email')
    #     fs = Form.objects.filter(roll_no=r,email=e)
    #     count = fs.count()
    #     if (count > 0):
    #         ps=fs[0].password
    #         send_mail('Password Recovery','Password is:'+ps,'vineettomar056@gmail.com',[e])
    #         return render(request, 'forgotpass.html',{'msg':'Password is send to registered email id'})
    #     else:
    #         return render(request, 'forgotpass.html', {'msg':'Invalid Userid or Email'})

def login(request):
    if(request.method=='GET'):
        return render(request,'register.html')
    else:
        r = request.POST.get('roll_no')
        n = request.POST.get('name')
        a = request.POST.get('age')
        f = request.POST.get('father_name')
        m = request.POST.get('mobile_number')
        c = request.POST.get('college_name')
        ca = request.POST.get('college_address')
        city = request.POST.get('city')
        t=request.POST.get('type')
        form=Form(roll_no=r,name=n,age=a,father_name=f,mobile_number=m,college_name=c,college_address=ca,city=city,type=t)
        try:
            form.save()
            resp=render(request,'register.html',{'msg':'Form Submitted Successfully...'})
            return resp
        except Exception as e:
            resp = render(request, 'register.html', {'msg':'Something went wrong,please try with different rollno'})
            return resp
        # return render(request,'default.html',{'msg':'Form Submitted'})

def auth(request):
    if(request.method=='GET'):
        return render(request, 'login.html')
    else:
        r=request.POST.get('roll_no')
        p=request.POST.get('pass')
        fs=Form.objects.filter(roll_no=r,password=p)
        count=fs.count()
        if(count>0):
            request.session['roll_no']=r
            row=fs.first()
            return render(request,'login.html')
        else:
            return render(request,'home.html',{'msg':'Invalid Userid or Password'})

def updateform(request):
    if (request.method == 'GET'):
        return render(request, 'updateform.html')
    else:
        p = request.POST.get('pass')
        n = request.POST.get('name')
        m = request.POST.get('mobile_number')
        a = request.POST.get('age')
        f = request.POST.get('father_name')
        c = request.POST.get('college_name')
        ca = request.POST.get('college_address')
        city = request.POST.get('city')
        t = request.POST.get('type')
        r = request.session.get('roll_no')
        form = Form.objects.get(roll_no=r)
        form.password = p
        form.name = n
        form.mobile_number = m
        form.age = a
        form.father_name = f
        form.college_name = c
        form.college_address = ca
        form.city = city
        form.type = t
        try:
            form.save()
            resp=render(request,'updateform.html',{'msg':'Form Updated Successfully...'})
            return resp
        except Exception as e:
            resp = render(request, 'updateform.html', {'msg':'Something went wrong,please try with different rollno'})
            return resp
        # return render(request, 'updateform.html', {'msg': 'Form Updated'})

def viewform(request):
    r=request.session.get('roll_no')
    row=Form.objects.get(roll_no=r)
    return render(request,'viewform.html',{'row':row})

def deleteform(request,roll_no):
    pass
    # context ={} 
    # obj = get_object_or_404(Form, roll_no=roll_no) 
  
    # if request.method =="POST":  
    #     obj.delete()  
    #     return HttpResponseRedirect("/")
  
    # return render(request, "deleteform.html", context) 

def logout(request):
    return render(request,'logout.html')