from django.apps import AppConfig


class CollegeFormConfig(AppConfig):
    name = 'college_form'
