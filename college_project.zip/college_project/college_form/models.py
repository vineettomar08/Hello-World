from django.db import models

# Create your models here.

class Form(models.Model):
	name = models.CharField(max_length=20)
	mobile_number=models.IntegerField()
	age = models.IntegerField()
	father_name = models.CharField(max_length = 20)
	college_name = models.CharField(max_length= 50)
	college_address = models.CharField(max_length=100)
	city = models.CharField(max_length=20)
	roll_no = models.IntegerField(unique=True)
	password = models.CharField(max_length=30,default='null')
	type = models.CharField(max_length=20)

	class Meta:
		db_table = "myform"